var n1, n2, soma;

n1 = parseInt(prompt("Digite um número: "));
n2 = parseInt(prompt("Digite outro número: "));
soma = n1 + n2;
alert("A soma dos dois números é: " + soma);