alert("Script Externo");
prompt("Digite seu nome:");
confirm("Você tem mais de 18 anos?");