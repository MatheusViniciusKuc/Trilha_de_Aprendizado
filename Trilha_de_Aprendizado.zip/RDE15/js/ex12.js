var v=[4, 8, 7, 6];

/*alert(v);

v[1] = 9;

alert(v);*/

lista = ["Zequinha", 1880, "Estrada A", "Irati", "PR", 80.5];
alert(lista);

for(var i=0;i<lista.length;i++){
    document.write("<h2>"+lista[i]+"</h2>")
}

lista.push("84500-000"); //adiciona item na última posição
lista.push("Rio Bonito"); //adiciona item na última posição
alert(lista);

lista.pop();//remover o último elemento da lista
alert(lista);

lista.shift()//Remover o primeiro elemento da lista;
lista.unshift("Juquinha")//adiciona item ao primeiro elemento da lista

alert(lista)

alert(lista.indexOf("Irati")); //procura o indice de uma palavra e caso encontre retorna o indice e  caso não retorna -1.