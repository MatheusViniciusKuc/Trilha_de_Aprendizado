var n1,n2, divisao;

n1 = parseInt(prompt("Digite um número inteiro: "));
n2 = parseInt(prompt("Digite outro número inteiro: "));
divisao = (n1/n2);
alert("A divisão dos números inteiro é: " + divisao);