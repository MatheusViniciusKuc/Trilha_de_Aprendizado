var n1, n2, resultado, frase;

n1 = 8;
n2 = 20;

alert(n1);
alert(n2);
resultado = n1+n2;
alert(resultado);
alert((n1+n2)/n2);
frase="O resultado da soma é";
alert(frase);
alert(frase + "ffff" + n1);