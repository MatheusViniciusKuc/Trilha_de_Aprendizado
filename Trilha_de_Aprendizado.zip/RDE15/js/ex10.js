var cont

cont=0;

/*while (cont < 10) {
    alert("Elouquecendo o usuario com while " + cont);
    cont++;
}*/

for(cont;cont<10;cont++){
    alert("Elouquecendo o usuario com for " + cont);
}